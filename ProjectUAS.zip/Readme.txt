Admin
CRUD Tamu 
CRUD Buku
CRUD Anggota
CRUD Peminjaman Buku
CRUD Donasi
Database Masukan dan Saran

Anggota
Home 

Daftar Buku
Riwayat Peminjaman Buku
Riwayat Kedatangan
Masukkan Dan Saran

Profile
Setting


Non Anggota
Home

Daftar Keanggotaan
Daftar Buku
Buku Tamu
Masukkan Dan Saran

login
setting


CRUD Tamu 
CRUD Buku
CRUD Anggota
CRUD Peminjaman Buku
CRUD Donasi
Database Masukan dan Saran
Home 
Daftar Buku
Riwayat Peminjaman Buku
Riwayat Kedatangan
Masukkan Dan Saran
Daftar Keanggotaan
Daftar Buku
Buku Tamu